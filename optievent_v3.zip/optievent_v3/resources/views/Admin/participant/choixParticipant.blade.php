<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="{{asset('Admin/style.css')}}">
        <title>Choix de participant</title>
    </head>
    <body>
			<div class="participant">
                <h2>Quel type de participant etes vous?</h2>
				<div class="groupe">
					<input type="submit" class="button" value="Participant sans Entreprise">
				</div>
				<div class="groupe">
					<input type="submit" class="button" value="Participant avec Entreprise">
				</div>
			</div>
</div>
    </body>
</html>